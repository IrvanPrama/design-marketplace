
<?php $__env->startSection('name','Detail Produk'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row mt-5 mb-5">
        <!-- Slide Galery -->
        <div class="col-lg-5" style="position: relative;">
            <div class="row mx-auto">
                <?php $__currentLoopData = $dt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="mySlides mx-auto" style="z-index:1000;">
                    <div class="numbertext">1 / 3</div>
                    <img src="<?php echo e(asset('/assets/design/'.$item->design1)); ?>" style="max-width:100%; height:400px;">
                </div>
                <div class="mySlides mx-auto" style="z-index:1000;">
                    <div class="numbertext">2 / 3</div>
                    <img src="<?php echo e(asset('/assets/design/'.$item->design2)); ?>" style="max-width:100%; height:400px;">
                </div>
                <div class="mySlides mx-auto" style="z-index:1000;">
                    <div class="numbertext">3 / 3</div>
                    <img src="<?php echo e(asset('/assets/design/'.$item->design3)); ?>" style="max-width:100%; height:400px;">
                </div>
                <div class="box mx-auto"
                    style="background-color: rgba(128, 128, 128, 0.459); width:450px; height:400px; margin-top:-400px;">
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <!-- Thumbnail images -->
            <div class="row mt-3 mx-auto">
                <div class="d-flex justify-content-xl-between">
                    <?php $__currentLoopData = $dt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="column">
                        <img class="demo cursor" src="<?php echo e(asset('/assets/design/'.$item->design1)); ?>"
                            style="width:130px; height:130px" onclick="currentSlide(1)" alt="The Woods">
                    </div>
                    <div class="column">
                        <img class="demo cursor" src="<?php echo e(asset('/assets/design/'.$item->design2)); ?>"
                            style="width:130px; height:130px" onclick="currentSlide(2)" alt="Cinque Terre">
                    </div>
                    <div class="column">
                        <img class="demo cursor" src="<?php echo e(asset('/assets/design/'.$item->design3)); ?>"
                            style="width:130px; height:130px" onclick="currentSlide(3)" alt="Mountains and fjords">
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <!-- End Slide Galery -->

        <div class="col-lg-7">
            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row ml-4">
                <img src=" <?php if(!is_null($item->avatar)): ?>
                <?php echo e(asset('/assets/profile/'.$item->avatar)); ?>

                <?php else: ?>
                <?php echo e(asset('/assets/profile/default.jpg')); ?>

                <?php endif; ?>" class="br-full" style="height: 60px; width:60px" alt="">
                <div class="row">
                    <div class="ml-4">
                        <h5 class="uppercase text-oten mb-1 text_capital"><b><?php echo e($item->name); ?></b></h5>
                        <p><b><?php echo e($item->job); ?></b></p>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php $__currentLoopData = $dt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row ml-4">
                <div class="" style="border: 2px solid rgb(27, 118, 238); border-radius: 18px;">
                    <div class="box m-4">
                        <h4 class="text-oten"><b><?php echo e($item->title); ?></b></h4>
                        <div class="underline mt-3 mb-3 pt-3 pb-3"
                            style="border-top: 1px solid rgba(128, 128, 128, 0.685); border-bottom: 1px solid rgba(128, 128, 128, 0.685); width:100%;">
                            <p><?php echo e($item->description); ?><br></p>
                            <p>
                                <b>Langkah Pengerjaan</b>
                                <br>1. Anda Order / Konsultasi materi desaindan jelaskan detail kebutuhan desain anda.
                                <br>2. Saya kirimkan penawaran harga setelah ada kesepakatan
                                <br>3. Anda kirim materi desain yang diperlukan dan saya mulai mengerjakan lalu
                                kirimkan
                                hasil desain / dummy (revisi jika diperlukan)
                                <br>4. Saya kirim hasil akhir desain seteah di setujui
                            </p>
                        </div>
                        <div class="row">
                            <p>
                                <span><i class="far fa-clock" style="font-size: 20px"></i></span> Lama Pengerjaan: 3
                                Hari
                            </p>
                            <p><span><i class="far fa-money" style="font-size: 20px"></i></span> Rp.50.000</p>
                        </div>
                        <div class="row">

                            <a href="/dashboard/form/order/<?php echo e($item->id); ?>" class="btn btn-success mr-auto ml-auto"
                                style="width: 35%">Pesan Sekarang</a>
                            <a href="" class="btn btn-success mr-auto ml-auto" style="width: 35%">Chat Designer</a>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<div class="row">
    <div class="col-lg-5">
        <img src="<?php echo e(asset('/assets/logo.png')); ?>" alt="logo" style="height: 35px; width: 200px; margin: 30px 0;">
        <p class="text-white">AkuDesain adalah sebuah platform yang memudahkan anda dalam menemukan
            jasa
            desain.
            Sistem AkuDesain
            sangat mudah dipakai, cepat dalam respon dan membantu and secara akurat untuk mencari
            freelancer
            yang tepat</p>
    </div>
    <div class="col-lg-2"></div>
    <div class="col-lg-5 text-white">
        <p style=" margin: 30px 0 10px 0; font-weight: bold;">Kontak Kami</p>
        <ul>
            <li>
                <a href="#" style="text-decoration: none; color: white;">
                    <div class="row">
                        <img src="<?php echo e(asset('assets/ig.png')); ?>" alt="ig"
                            style="width: 18px; height: 18px; margin: 5px 10px;">
                        <p>akudesain_id</p>
                    </div>
                </a>
            </li>
            <li>
                <a href="#" style="text-decoration: none; color: white;">
                    <div class="row">
                        <img src="<?php echo e(asset('assets/facebook.png')); ?>" alt="fb" class="mini-icon"
                            style="width: 12px; height: 18px; margin: 5px 14px;">
                        <p>AkuDesain</p>
                    </div>
                </a>
            </li>
            <li>
                <a href="#" style="text-decoration: none; color: white;">
                    <div class="row">
                        <img src="<?php echo e(asset('assets/mail.png')); ?>" alt="mail"
                            style="width: 18px; height: 14px; margin: 5px 10px;">
                        <p>AkuDesain.official@gmail.com</p>
                    </div>
                </a>
            </li>
            <li>
                <a href="#" style="text-decoration: none; color: white;">
                    <div class="row">
                        <img src="<?php echo e(asset('assets/wa.png')); ?>" alt="wa"
                            style="width: 16px; height: 14px; margin: 5px 10px;">
                        <p>+62 87 776 966 876</p>
                    </div>
                </a>
            </li>
        </ul>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    var slideIndex = 1;
showSlides(slideIndex);

// Next/previous controls
function plusSlides(n) {
  showSlides(slideIndex += n);
}

// Thumbnail image controls
function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("demo");
  var captionText = document.getElementById("caption");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
  captionText.innerHTML = dots[slideIndex-1].alt;
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.master-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\PESANAN\WEBSITE\akudesain-webapp\resources\views/detail/user.blade.php ENDPATH**/ ?>