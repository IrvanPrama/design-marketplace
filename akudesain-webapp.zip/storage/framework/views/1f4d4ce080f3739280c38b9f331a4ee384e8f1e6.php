

<?php $__env->startSection('name','Edit | Akudesain'); ?>

<?php $__env->startSection('content'); ?>

<body style="background-color: rgb(231, 231, 231);">

    <div class="jumbotron-user jumbotron-fluid mt-0" style="padding-top:320px;">
        <div class="profil">
            <p class="text-1 mb-3 bold white">Edit Profil</p>
            <div class="mx-auto d-block" style="height:210px; width: 210px;" type="button" data-toggle="modal"
                data-target="#editAvatarModal">

                <img class="br-full" src="
                
                <?php if(!is_null(auth()->user()->avatar)): ?>
                <?php echo e(asset('/storage/images/profile/'.auth()->user()->avatar)); ?>

            
                <?php else: ?>
                <?php echo e(asset('/atorage/images/profile/default.jpg')); ?>

                <?php endif; ?>
                
                
                
                " alt="" style="width: 200px; height: 200px;">
                <div class="br-full bg-white pt-2" style="height: 50px;
                width: 50px;
                margin-top: -55px;
                position: relative;
                z-index: 155;
                margin-left: 145px;"><i class="fas fa-camera fa-2x"></i></div>
            </div>
        </div>
    </div>

    <div class="container px-5 pb-5" style="margin-top: 170px;">

        <!-- Menu Tab -->
        <section class="col-lg-12 mt-5">
            <div class="row">
                <a href="/dashboard/designer/edit-profile" class="btn bg-white color-oten"
                    style="height:40px; width:150px;">
                    <p class="color-oten" style="text-align: center;"><b>Profil</b></p>
                </a>
                <a href="/dashboard/designer/edit-portofolio" class="btn" style="height:40px; width:150px;">
                    <p class=" color-oten" style="text-align: center;"><b>Portofolio</b></p>
                </a>
            </div>
        </section>
        <!-- End Menu Tab -->

        <!-- Content -->
        <section class="mb-5">
            <!-- Desain Terbaru -->
            <div class="col-lg-12 bg-white mt-0 px-4 py-4">
                <form class="mx-auto" style="width: 80%" action="/store-update-profile" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <input class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Nama Lengkap" type="text" name="name" id="input-edit"
                            value="<?php echo e(auth()->user()->name); ?>">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <input class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Username" type="text" name="username" id="input-edit"
                            value="<?php echo e(auth()->user()->username); ?>">
                        <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <textarea class="form-control <?php $__errorArgs = ['about'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="about" rows="4" id="about"><?php if(is_null(auth()->user()->about)): ?>
Ceritakan sedikit tentang anda (max: 300 karakter)
<?php else: ?> 
<?php echo e(auth()->user()->about); ?>

<?php endif; ?></textarea>
                        <?php $__errorArgs = ['about'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-row">
                        <div class="col-md-8 mb-3">
                            <label for="validationDefaultUsername">No. HP /
                                Whatsapp</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="inputGroupPrepend2">+62</span>
                                </div>
                                <input type="tel" value="<?php echo e(auth()->user()->no_hp); ?>" id="now_hp" name="no_hp" class="form-control <?php $__errorArgs = ['no_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="validationDefaultUsername" placeholder="No. HP / WA"
                                    aria-describedby="inputGroupPrepend2" required>
                                <?php $__errorArgs = ['no_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group col-md-4">
                            <label for="born">Tgl. Lahir</label>
                            <input class="form-control <?php $__errorArgs = ['born'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> ml-2" value="<?php echo e(auth()->user()->born); ?>" placeholder="Tanggal Lahir"
                                type="date" name="born" id="input-edit">
                            <?php $__errorArgs = ['born'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <label for="experience">Pekerjaan / Perusahaan</label>
                            <input class="form-control <?php $__errorArgs = ['experience'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="experience" name="experience" value="<?php echo e(auth()->user()->experience); ?>"
                                placeholder="PT. Indonesia Persada" type="text" id="input-edit">
                            <?php $__errorArgs = ['experience'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-3">
                            <label for="job">Job</label>
                            <input class="form-control <?php $__errorArgs = ['job'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(auth()->user()->job); ?>" name="job" placeholder="Pekerjaan"
                                type="text">
                            <?php $__errorArgs = ['job'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-3">
                            <label for="start">Sejak</label>
                            <input class="form-control <?php $__errorArgs = ['start'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="start" placeholder="Sejak" type="date"
                                value="<?php echo e(auth()->user()->start); ?>" name="start" id="input-edit">
                            <?php $__errorArgs = ['start'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-3">
                            <label for="until">Sampai</label>
                            <input class="form-control <?php $__errorArgs = ['until'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Sampai" type="date" value="<?php echo e(auth()->user()->until); ?>"
                                name="until" id="input-edit">
                            <?php $__errorArgs = ['until'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="step">Alur Kerja</label>
                        <textarea name="step" type="text" id="alur" name="step" class="form-control <?php $__errorArgs = ['step'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="10">
1. Anda memesan
2. Saya mengkonfirmasi dan memastikan pesanan anda.
3. Saya mengerjakan pesanan.
4. Saya mengirim gambaran hasil.
5. Anda memberikan revisi
6. Saya kirim hasil revisi
7. Anda melakukan pembayaran.
8. Saya mengirim design.
                        </textarea>
                        <?php $__errorArgs = ['step'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button onclick="myFunction()" type="submit" class="btn btn-block btn-success">Simpan</button>
                </form>
            </div>
            <div class="col-lg-12 bg-white mt-0 px-4 my-2 py-4">
                <form class="mx-auto" style="width: 80%" action="/store-update-password-designer" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <p class="text-2">Edit Password</p>
                    <div class="form-group">
                        <input placeholder="Password Baru" type="password" name="password_lama" class="form-control">
                    </div>
                    <div class="form-group">
                        <input placeholder="Confirm Password" type="password" name="password" class="form-control">
                    </div>
                    <button type="submit" class="btn btn-success ml-auto">Ganti</button>
                </form>
            </div>
            <!-- End Desain Terbaru -->
        </section>
        <!-- End Content -->

    </div>

</body>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
<!-- Modal Edit Design-->
<div class="modal fade" id="editAvatarModal" tabindex="-1" z-index="10" role="dialog"
    aria-labelledby="exampleModalCenter" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content br-0">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Update Foto Profil</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="/store-update-avatar-designer" method="post" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group mb-4">
                        <label for="name">Unggah Foto</label>
                        <input type="file" name="avatar" class="form-control" value="<?php echo e(auth()->user()->avatar); ?>">
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary" style="border-radius: 0">Unggah</button>
                        </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- End Modal Edit Design-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    function myFunction() {
        var strr = $('#now_hp').val();

        str = strr.replace(/0(\d+)/, "$1");

        document.getElementById('now_hp').value = str;
        console.log(str)
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard-designer.master-designer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\PESANAN\WEBSITE\akudesain-webapp\resources\views/dashboard-designer/profile-edit.blade.php ENDPATH**/ ?>