

<?php $__env->startSection('name','Dashboard | Edit'); ?>

<?php $__env->startSection('nav-item'); ?>
<div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
        <div class="btn-group">
            <button class="btn" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                style="border-radius:18px;">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item mr-3 ml-3 pt-2">
                        <p class="text-white text_capital"><b><?php echo e(auth()->user()->name); ?></b></p>
                    </li>
                    <li class="nav-item">
                        <div class="nav-linkdropdown-toggle text-white" type="button" data-toggle="dropdown"
                            aria-haspopup="true" aria-expanded="false">
                            <img type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
                                class="br-full" src="<?php echo e(asset('/assets/profile/'.auth()->user()->avatar)); ?>" alt="profil"
                                style="width: 40px; height:40px;">
                        </div>
                    </li>
                </ul>
            </button>
            <div class="dropdown-menu">
                <a class="dropdown-item" type="button" data-toggle="modal" data-target="#profileModal">Edit Profile</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" type="button" data-toggle="modal" data-target="#reviewModal">Buat Review</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" type="button" href="<?php echo e(route('logout')); ?>">Log Out</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#">Status <b><?php echo e(auth()->user()->role); ?></b></a>
            </div>
        </div>
    </ul>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<body style="background-color: rgb(231, 231, 231);">

    <div class="container">

        <!-- Menu Tab -->
        <section class="mt-5">
            <div class="row">
                <a class="btn" style="height:40px; width:180px;">
                    <p class="color-oten" style="text-align: center;"><b>Profil</b></p>
                </a>
                <a href="/dashboard/designer/ongoing" class="btn bg-white color-oten" style="height:40px; width:100px;">
                    <p class=" color-oten" style="text-align: center;"><b>Portofolio</b></p>
                </a>
            </div>
        </section>
        <!-- End Menu Tab -->

        <!-- Content -->
        <section class="mb-5">
            <!-- Desain Terbaru -->
            <div class="col-lg-12 bg-white mt-0 px-4 py-4">
                <div class="row">
                    <a href="" style="line-height: 1.8;" class="btn btn-success ml-auto mr-2 bold">Tambah Portofolio</a>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $datadesign; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="/detail/<?php echo e($item->id); ?>" class="card br-0"
                        style="border: solid 4px rgba(0, 110, 255, 0.815);height: 275px;" data-toggle="modal"
                        data-target="#designModal<?php echo e($item->id); ?>">
                        <div class="row mt-0">
                            <img class="profil-card mb-1" src="<?php echo e(asset('/assets/profile/'.$item->avatar)); ?>"
                                alt="profil">
                            <p class="text-oten text_capital"
                                style="margin:5px 0; padding: 5px 0; font-size: 18px; font-weight: bold;">
                                <?php echo e($item->name); ?>

                            </p>
                        </div>
                        <div class="image"
                            style="height: 220px; width:220px; background-image: url('<?php echo e(asset('/assets/design/'.$item->design1)); ?>'); background-repeat: no-repeat; background-size: cover; background-position: center; margin-right: 6px; margin-left: 6px;">
                        </div>
                        <p class="text-3 bold text_capital text-oten text-center" style="margin:5px 0;">
                            <?php echo e($item->title); ?></p>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <!-- End Desain Terbaru -->
        </section>
        <!-- End Content -->


    </div>

</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\PESANAN\WEBSITE\akudesain-webapp\resources\views/dashboard-designer/edit.blade.php ENDPATH**/ ?>